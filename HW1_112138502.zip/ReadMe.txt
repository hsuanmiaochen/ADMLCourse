直接讀取 hw1.py 即可得到所有 results.
(AD_HW1資料夾中為各方法分開寫的程式碼)