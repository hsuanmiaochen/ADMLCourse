
########################################################
########  Do not modify the sample code segment ########
########################################################

import torchvision
import numpy as np
import torch
import tqdm
from sklearn.metrics import roc_auc_score

seed = 0
np.random.seed(seed)

def resample_total(data,label,ratio=0.05):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        ratio: float, ratio of samples to be selected
    """
    new_data = []
    new_label = []
    for i in range(10):
        i_data = data[label==i]
        idx = np.random.choice(list(range(len(i_data))),int(len(i_data)*ratio),replace=False)
        new_data.append(i_data[idx])
        new_label.append(np.ones(len(idx))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

def resample(data,label,outlier_ratio=0.01,target_label=0):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        outlier_ratio: float, ratio of outliers
        target_label: int, the label to be treated as normal
    """
    new_data = []
    new_label = []
    for i in range(10):
        if i != target_label:
            i_data = data[label==i]
            target_size = len(data[label==target_label])
            num = target_size*((outlier_ratio/9))
            idx = np.random.choice(list(range(len(i_data))),int(num),replace=False)
            new_data.append(i_data[idx])
            new_label.append(np.ones(len(idx))*i)
        else:
            new_data.append(data[label==i])
            new_label.append(np.ones(len(data[label==i]))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

if __name__=="__main__":
    orig_train_data = torchvision.datasets.MNIST("MNIST/", train=True, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST訓練資料
    orig_test_data = torchvision.datasets.MNIST("MNIST/", train=False, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST測試資料

    orig_train_label = orig_train_data.targets.numpy()
    orig_train_data = orig_train_data.data.numpy()
    orig_train_data = orig_train_data.reshape(60000,28*28)

    orig_test_label = orig_test_data.targets.numpy()
    orig_test_data = orig_test_data.data.numpy()
    orig_test_data = orig_test_data.reshape(10000,28*28)

    # PCA
    from sklearn.decomposition import PCA
    pca = PCA(n_components=30)
    pca_data = pca.fit_transform(np.concatenate([orig_train_data,orig_test_data]))
    orig_train_data = pca_data[:len(orig_train_label)]
    orig_test_data = pca_data[len(orig_train_label):]

    orig_train_data,orig_train_label = resample_total(orig_train_data,orig_train_label,ratio=0.1)
    
    roc_auc_scores = []
    
    for i in tqdm.tqdm(range(10)):
        train_data = orig_train_data[orig_train_label==i]
        test_data,test_label = resample(orig_test_data,orig_test_label,target_label=i,outlier_ratio=0.1)
        # [TODO] prepare training/testing data with label==i labeled as 0, and others labeled as 1

        # Prepare training data: label i as 0 and others as 1
        train_data = orig_train_data.copy()  # Create a copy of original training data
        train_label = np.where(orig_train_label == i, 0, 1)  # Set label i as 0, others as 1

        # Prepare testing data: label i as 0 and others as 1
        test_data, test_label = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)  # Resample test data
        test_label = np.where(test_label == i, 0, 1)  # Set label i as 0, others as 1


        # [TODO] implement methods
        # Cluster-based
        def euclidean_distance(x1, x2):
            return np.sqrt(np.sum((x1 - x2) ** 2))

        def k_means_clustering(train_data, k, max_iter=100):
            centroids = train_data[np.random.choice(train_data.shape[0], k, replace=False)] # Initialize centroids randomly
            for _ in range(max_iter): # Assign each data point to the nearest centroid
                clusters = [[] for _ in range(k)]
                for i, data_point in enumerate(train_data):
                    distances = [euclidean_distance(data_point, centroid) for centroid in centroids]
                    cluster_index = np.argmin(distances)
                    clusters[cluster_index].append(i)
                
                # Update centroids
                new_centroids = []
                for cluster in clusters:
                    cluster_mean = np.mean(train_data[cluster], axis=0)
                    new_centroids.append(cluster_mean)
                new_centroids = np.array(new_centroids)
                
                # Check for convergence
                if np.allclose(centroids, new_centroids):
                    break
                centroids = new_centroids
                
            return clusters
        
        def calculate_roc_auc(train_labels, clusters, k):
            predictions = np.zeros_like(train_labels)
            for i, cluster in enumerate(clusters):
                predictions[cluster] = i
            
            # Compute ROC-AUC score
            roc_auc = roc_auc_score(train_labels, predictions, average='macro')
            return roc_auc

        # Set the number of clusters (k) to be used
        k_values = [1, 5, 10]
        roc_auc_scores = []

        for k in k_values:
            # Perform k-means clustering
            clusters = k_means_clustering(train_data, k)
            
            # Calculate ROC-AUC score
            roc_auc = calculate_roc_auc(train_label, clusters, k)
            roc_auc_scores.append(roc_auc)
        
        # Print the ROC-AUC scores for different values of k
        for k, roc_auc in zip(k_values, roc_auc_scores):
            print(f"  Mean ROC-AUC for k={k}: {roc_auc}")
        # [TODO] record ROC-AUC for each method
        

    # [TODO] print the average ROC-AUC for each method
    