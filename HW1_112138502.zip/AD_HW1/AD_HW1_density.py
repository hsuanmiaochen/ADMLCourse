import numpy as np
import torch
import torchvision
from tqdm import tqdm
from sklearn.metrics import roc_auc_score

seed = 0
np.random.seed(seed)

def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2))

def resample_total(data, label, ratio=0.05):
    new_data = []
    new_label = []
    for i in range(10):
        i_data = data[label == i]
        idx = np.random.choice(list(range(len(i_data))), int(len(i_data) * ratio), replace=False)
        new_data.append(i_data[idx])
        new_label.append(np.ones(len(idx)) * i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

def resample(data, label, outlier_ratio=0.01, target_label=0):
    new_data = []
    new_label = []
    for i in range(10):
        if i != target_label:
            i_data = data[label == i]
            target_size = len(data[label == target_label])
            num = target_size * ((outlier_ratio / 9))
            idx = np.random.choice(list(range(len(i_data))), int(num), replace=False)
            new_data.append(i_data[idx])
            new_label.append(np.ones(len(idx)) * i)
        else:
            new_data.append(data[label == i])
            new_label.append(np.ones(len(data[label == i])) * i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

if __name__ == "__main__":
    orig_train_data = torchvision.datasets.MNIST(
        "MNIST/",
        train=True,
        transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),
        target_transform=None,
        download=True,
    )
    orig_test_data = torchvision.datasets.MNIST(
        "MNIST/",
        train=False,
        transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),
        target_transform=None,
        download=True,
    )

    orig_train_label = orig_train_data.targets.numpy()
    orig_train_data = orig_train_data.data.numpy()
    orig_train_data = orig_train_data.reshape(60000, 28 * 28)

    orig_test_label = orig_test_data.targets.numpy()
    orig_test_data = orig_test_data.data.numpy()
    orig_test_data = orig_test_data.reshape(10000, 28 * 28)

    # PCA
    from sklearn.decomposition import PCA

    pca = PCA(n_components=30)
    pca_data = pca.fit_transform(np.concatenate([orig_train_data, orig_test_data]))
    orig_train_data = pca_data[: len(orig_train_label)]
    orig_test_data = pca_data[len(orig_train_label) :]

    orig_train_data, orig_train_label = resample_total(orig_train_data, orig_train_label, ratio=0.1)

    for i in tqdm(range(10)):
        train_data = orig_train_data[orig_train_label == i]
        test_data, test_label = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)

        # Prepare training data: label i as 0 and others as 1
        train_data_binary = orig_train_data.copy()
        train_label_binary = np.where(orig_train_label == i, 0, 1)

        # Prepare testing data: label i as 0 and others as 1
        test_data_binary, test_label_binary = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)
        test_label_binary = np.where(test_label_binary == i, 0, 1)

        import matplotlib.pyplot as plt
        from scipy.spatial.distance import cdist    

        # Density-based
        N=test_data.shape[0]
        k=5
        distance_matrix = cdist(test_data, train_data ,"euclidean")
        k_distance=np.sort(distance_matrix,axis=0)[k+1]
        k_distance_matrix=np.outer(np.ones(N),k_distance)
        reach_distacne=np.maximum(distance_matrix,k_distance_matrix)

        sort_index=np.argsort(distance_matrix,axis=1)[:,1:k+1]
        LRD=np.zeros(N)
        for i in range(N):
            LRD[i]=1/np.mean(reach_distacne[i,sort_index[i]]) 
        
        LOF=np.zeros(N)
        for i in range(N):
            LOF[i]=np.mean(LRD[sort_index[i]])/LRD[i]

        # Compute ROC-AUC for each class
        roc_auc_scores = []
        for i in range(10):
            binary_labels = np.where(test_label == i, 1, 0)
            roc_auc = roc_auc_score(binary_labels, LOF)
            roc_auc_scores.append(roc_auc)
            
        #(a)
        # Compute mean ROC-AUC
        mean_roc_auc = np.mean(roc_auc_scores)
        print("  Mean ROC-AUC:", mean_roc_auc)

       #(b)
        from sklearn.manifold import TSNE
        # 使用 t-SNE 將測試集數據轉換為低維表示
        tsne = TSNE(n_components=2)
        X_tsne = tsne.fit_transform(test_data)

        # 創建一個 Matplotlib 子圖
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

        #LOF 異常得分
        scatter1 = ax1.scatter(X_tsne[:, 0], X_tsne[:, 1], c=LOF, cmap='coolwarm', s=80)
        ax1.set_title('predicted LoF score for normal digit=0')

        # ground truth label
    scatter2 = ax2.scatter(X_tsne[:, 0], X_tsne[:, 1], c=test_label_binary, cmap='coolwarm', s=80, vmin = 0, vmax = 1)

    ax2.set_title('ground truth label for normal digit=0')

    cbar1 = fig.colorbar(scatter1, ax=ax1)
    cbar1.set_label('LOF Score')
    # cbar2 = fig.colorbar(scatter2, ax=ax2)
    # cbar2.set_label('Ground Truth Label')

    plt.show()
