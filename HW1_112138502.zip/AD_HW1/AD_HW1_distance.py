
########################################################
########  Do not modify the sample code segment ########
########################################################

import torchvision
import numpy as np
import torch
import tqdm
from sklearn.metrics import roc_auc_score

seed = 0
np.random.seed(seed)

def resample_total(data,label,ratio=0.05):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        ratio: float, ratio of samples to be selected
    """
    new_data = []
    new_label = []
    for i in range(10):
        i_data = data[label==i]
        idx = np.random.choice(list(range(len(i_data))),int(len(i_data)*ratio),replace=False)
        new_data.append(i_data[idx])
        new_label.append(np.ones(len(idx))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

def resample(data,label,outlier_ratio=0.01,target_label=0):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        outlier_ratio: float, ratio of outliers
        target_label: int, the label to be treated as normal
    """
    new_data = []
    new_label = []
    for i in range(10):
        if i != target_label:
            i_data = data[label==i]
            target_size = len(data[label==target_label])
            num = target_size*((outlier_ratio/9))
            idx = np.random.choice(list(range(len(i_data))),int(num),replace=False)
            new_data.append(i_data[idx])
            new_label.append(np.ones(len(idx))*i)
        else:
            new_data.append(data[label==i])
            new_label.append(np.ones(len(data[label==i]))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

if __name__=="__main__":
    orig_train_data = torchvision.datasets.MNIST("MNIST/", train=True, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST訓練資料
    orig_test_data = torchvision.datasets.MNIST("MNIST/", train=False, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST測試資料

    orig_train_label = orig_train_data.targets.numpy()
    orig_train_data = orig_train_data.data.numpy()
    orig_train_data = orig_train_data.reshape(60000,28*28)

    orig_test_label = orig_test_data.targets.numpy()
    orig_test_data = orig_test_data.data.numpy()
    orig_test_data = orig_test_data.reshape(10000,28*28)

    # PCA
    from sklearn.decomposition import PCA
    pca = PCA(n_components=30)
    pca_data = pca.fit_transform(np.concatenate([orig_train_data,orig_test_data]))
    orig_train_data = pca_data[:len(orig_train_label)]
    orig_test_data = pca_data[len(orig_train_label):]

    orig_train_data,orig_train_label = resample_total(orig_train_data,orig_train_label,ratio=0.1)
    
    roc_auc_scores = []
    
    for i in tqdm.tqdm(range(10)):
        train_data = orig_train_data[orig_train_label==i]
        test_data,test_label = resample(orig_test_data,orig_test_label,target_label=i,outlier_ratio=0.1)
        # [TODO] prepare training/testing data with label==i labeled as 0, and others labeled as 1

        # Prepare training data: label i as 0 and others as 1
        train_data = orig_train_data.copy()  # Create a copy of original training data
        train_label = np.where(orig_train_label == i, 0, 1)  # Set label i as 0, others as 1

        # Prepare testing data: label i as 0 and others as 1
        test_data, test_label = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)  # Resample test data
        test_label = np.where(test_label == i, 0, 1)  # Set label i as 0, others as 1


        # [TODO] implement methods
        def cosine_distance(u, v): # Compute cosine similarity
            dot_product = np.dot(u, v)
            norm_u = np.linalg.norm(u)
            norm_v = np.linalg.norm(v)
            cosine_similarity = dot_product / (norm_u * norm_v)
            # Convert cosine similarity to cosine distance
            cosine_distance = 1 - cosine_similarity
            return cosine_distance
        
        def minkowski_distance(u, v, r): # Compute Minkowski Distance
            minkowski_distance = np.power(np.sum(np.abs(u - v) ** r), 1/r)
            return minkowski_distance

        def mahalanobis_distance(u, v, cov):# Compute Mahalanobis Distance
            diff = u - v
            mahalanobis_distance = np.sqrt(np.dot(np.dot(diff.T, np.linalg.inv(cov)), diff))
            return mahalanobis_distance
        cov_matrix = np.cov(test_data, rowvar=False)

        # [TODO] record ROC-AUC for each method
        from sklearn.metrics import roc_auc_score, pairwise_distances
        def k_nearest_neighbors(distances_matrix, train_labels, k):
            predictions = []
            for distances_to_train_samples in distances_matrix:
                nearest_neighbors_indices = np.argsort(distances_to_train_samples)[:k]
                nearest_neighbors_labels = [train_labels[i] for i in nearest_neighbors_indices]
                predicted_label = max(set(nearest_neighbors_labels), key=nearest_neighbors_labels.count)
                predictions.append(predicted_label)
            return predictions

        # ROC-AUC
        mean_roc_auc = {}
        for distance_name, distance_matrix in [("Cosine Distance", pairwise_distances(test_data, test_data, metric=cosine_distance)),
                                        ("Minkowski Distance r=1", pairwise_distances(test_data, test_data, metric=minkowski_distance, r=1)),
                                        ("Minkowski Distance r=2", pairwise_distances(test_data, test_data, metric=minkowski_distance, r=2)),
                                        ("Minkowski Distance r=inf", pairwise_distances(test_data, test_data, metric=minkowski_distance, r=np.inf)),
                                        ("Mahalanobis Distance", pairwise_distances(test_data, test_data, metric=mahalanobis_distance, cov=cov_matrix))]:    
            predictions = k_nearest_neighbors(distance_matrix, train_label, k=5)
            # 計算每個數字的 ROC-AUC
            roc_auc_per_digit = {}
            for digit in range(2):
                true_labels = (test_label == digit).astype(int)
                predicted_scores = [(pred == digit) for pred in predictions]
                roc_auc_per_digit[digit] = roc_auc_score(true_labels, predicted_scores)
            mean_roc_auc[distance_name] = np.mean(list(roc_auc_per_digit.values()))

        print("  Mean ROC-AUC:")
        for distance_name, roc_auc in mean_roc_auc.items():
            print(f"{distance_name}: {roc_auc}")
        