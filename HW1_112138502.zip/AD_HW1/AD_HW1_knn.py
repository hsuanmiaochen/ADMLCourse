
########################################################
########  Do not modify the sample code segment ########
########################################################

import torchvision
import numpy as np
import torch
import tqdm
from sklearn.metrics import roc_auc_score

seed = 0
np.random.seed(seed)

def resample_total(data,label,ratio=0.05):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        ratio: float, ratio of samples to be selected
    """
    new_data = []
    new_label = []
    for i in range(10):
        i_data = data[label==i]
        idx = np.random.choice(list(range(len(i_data))),int(len(i_data)*ratio),replace=False)
        new_data.append(i_data[idx])
        new_label.append(np.ones(len(idx))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

def resample(data,label,outlier_ratio=0.01,target_label=0):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        outlier_ratio: float, ratio of outliers
        target_label: int, the label to be treated as normal
    """
    new_data = []
    new_label = []
    for i in range(10):
        if i != target_label:
            i_data = data[label==i]
            target_size = len(data[label==target_label])
            num = target_size*((outlier_ratio/9))
            idx = np.random.choice(list(range(len(i_data))),int(num),replace=False)
            new_data.append(i_data[idx])
            new_label.append(np.ones(len(idx))*i)
        else:
            new_data.append(data[label==i])
            new_label.append(np.ones(len(data[label==i]))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

if __name__=="__main__":
    orig_train_data = torchvision.datasets.MNIST("MNIST/", train=True, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST訓練資料
    orig_test_data = torchvision.datasets.MNIST("MNIST/", train=False, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST測試資料

    orig_train_label = orig_train_data.targets.numpy()
    orig_train_data = orig_train_data.data.numpy()
    orig_train_data = orig_train_data.reshape(60000,28*28)

    orig_test_label = orig_test_data.targets.numpy()
    orig_test_data = orig_test_data.data.numpy()
    orig_test_data = orig_test_data.reshape(10000,28*28)

    # PCA
    from sklearn.decomposition import PCA
    pca = PCA(n_components=30)
    pca_data = pca.fit_transform(np.concatenate([orig_train_data,orig_test_data]))
    orig_train_data = pca_data[:len(orig_train_label)]
    orig_test_data = pca_data[len(orig_train_label):]

    orig_train_data,orig_train_label = resample_total(orig_train_data,orig_train_label,ratio=0.1)
    
    # Collect ROC-AUC scores for each method
    roc_auc_scores_k1 = []
    roc_auc_scores_k5 = []
    roc_auc_scores_k10 = []
    
    for i in tqdm.tqdm(range(10)):
        train_data = orig_train_data[orig_train_label==i]
        test_data,test_label = resample(orig_test_data,orig_test_label,target_label=i,outlier_ratio=0.1)
        # [TODO] prepare training/testing data with label==i labeled as 0, and others labeled as 1

        # Prepare training data: label i as 0 and others as 1
        train_data = orig_train_data.copy()  # Create a copy of original training data
        train_label = np.where(orig_train_label == i, 0, 1)  # Set label i as 0, others as 1

        # Prepare testing data: label i as 0 and others as 1
        test_data, test_label = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)  # Resample test data
        test_label = np.where(test_label == i, 0, 1)  # Set label i as 0, others as 1


        # [TODO] implement methods

        # K Nearest Neighbor
        def euclidean_distance(x1, x2):
            return np.sqrt(np.sum((x1 - x2) ** 2))
        
        def knn_classifier(train_data, train_labels, test_data, test_labels, k):
            predictions = [] # Initialize predictions list

            for test_point in test_data: # Loop through each test sample

                # Calculate distances between test point and all train points
                distances = [euclidean_distance(test_point, train_point) for train_point in train_data]
                nearest_indices = np.argsort(distances)[:k] # Get indices of k nearest neighbors
                nearest_labels = [train_labels[i] for i in nearest_indices] # Get labels of k nearest neighbors

                # Predict the class based on majority vote
                predicted_label = max(set(nearest_labels), key=nearest_labels.count)
                predictions.append(predicted_label) # Append the predicted label to the predictions list

            # Calculate ROC-AUC for all digits
            roc_auc = roc_auc_score(test_labels, predictions, average='macro')

            return roc_auc

        # Calculate ROC-AUC for k=1、5、10
        roc_auc_k1 = knn_classifier(train_data, train_label, test_data, test_label, k=1)
        roc_auc_k5 = knn_classifier(train_data, train_label, test_data, test_label, k=5)
        roc_auc_k10 = knn_classifier(train_data, train_label, test_data, test_label, k=10)
        
        # [TODO] record ROC-AUC for each method
        
        # Append ROC-AUC scores to respective lists
        roc_auc_scores_k1.append(roc_auc_k1)
        roc_auc_scores_k5.append(roc_auc_k5)
        roc_auc_scores_k10.append(roc_auc_k10)

        # Print the results
        print("ROC-AUC for k=1:", roc_auc_k1)
        print("ROC-AUC for k=5:", roc_auc_k5)
        print("ROC-AUC for k=10:", roc_auc_k10)

    # [TODO] print the average ROC-AUC for each method
    
    # Calculate average ROC-AUC scores for each method
    mean_roc_auc_k1 = np.mean(roc_auc_scores_k1)
    mean_roc_auc_k5 = np.mean(roc_auc_scores_k5)
    mean_roc_auc_k10 = np.mean(roc_auc_scores_k10)

    # Print the average ROC-AUC scores
    print("Average ROC-AUC for k=1:", mean_roc_auc_k1)
    print("Average ROC-AUC for k=5:", mean_roc_auc_k5)
    print("Average ROC-AUC for k=10:", mean_roc_auc_k10)
