
########################################################
########  Do not modify the sample code segment ########
########################################################

import torchvision
import numpy as np
import torch
import tqdm
from sklearn.metrics import roc_auc_score

seed = 0
np.random.seed(seed)

def resample_total(data,label,ratio=0.05):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        ratio: float, ratio of samples to be selected
    """
    new_data = []
    new_label = []
    for i in range(10):
        i_data = data[label==i]
        idx = np.random.choice(list(range(len(i_data))),int(len(i_data)*ratio),replace=False)
        new_data.append(i_data[idx])
        new_label.append(np.ones(len(idx))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

def resample(data,label,outlier_ratio=0.01,target_label=0):
    """
        data: np.array, shape=(n_samples, n_features)
        label: np.array, shape=(n_samples,)
        outlier_ratio: float, ratio of outliers
        target_label: int, the label to be treated as normal
    """
    new_data = []
    new_label = []
    for i in range(10):
        if i != target_label:
            i_data = data[label==i]
            target_size = len(data[label==target_label])
            num = target_size*((outlier_ratio/9))
            idx = np.random.choice(list(range(len(i_data))),int(num),replace=False)
            new_data.append(i_data[idx])
            new_label.append(np.ones(len(idx))*i)
        else:
            new_data.append(data[label==i])
            new_label.append(np.ones(len(data[label==i]))*i)
    new_data = np.concatenate(new_data)
    new_label = np.concatenate(new_label)
    return new_data, new_label

if __name__=="__main__":
    orig_train_data = torchvision.datasets.MNIST("MNIST/", train=True, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST訓練資料
    orig_test_data = torchvision.datasets.MNIST("MNIST/", train=False, transform=torchvision.transforms.Compose([torchvision.transforms.ToTensor()]),target_transform=None,download=True) #下載並匯入MNIST測試資料

    orig_train_label = orig_train_data.targets.numpy()
    orig_train_data = orig_train_data.data.numpy()
    orig_train_data = orig_train_data.reshape(60000,28*28)

    orig_test_label = orig_test_data.targets.numpy()
    orig_test_data = orig_test_data.data.numpy()
    orig_test_data = orig_test_data.reshape(10000,28*28)

    # PCA
    from sklearn.decomposition import PCA
    pca = PCA(n_components=30)
    pca_data = pca.fit_transform(np.concatenate([orig_train_data,orig_test_data]))
    orig_train_data = pca_data[:len(orig_train_label)]
    orig_test_data = pca_data[len(orig_train_label):]

    orig_train_data,orig_train_label = resample_total(orig_train_data,orig_train_label,ratio=0.1)
    
    # Collect ROC-AUC scores for each method
    roc_auc_scores_k1 = []
    roc_auc_scores_k5 = []
    roc_auc_scores_k10 = []
    
    for i in tqdm.tqdm(range(10)):
        train_data = orig_train_data[orig_train_label==i]
        test_data,test_label = resample(orig_test_data,orig_test_label,target_label=i,outlier_ratio=0.1)
        # [TODO] prepare training/testing data with label==i labeled as 0, and others labeled as 1

        # Prepare training data: label i as 0 and others as 1
        train_data = orig_train_data.copy()  # Create a copy of original training data
        train_label = np.where(orig_train_label == i, 0, 1)  # Set label i as 0, others as 1

        # Prepare testing data: label i as 0 and others as 1
        test_data, test_label = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)  # Resample test data
        test_label = np.where(test_label == i, 0, 1)  # Set label i as 0, others as 1


        # [TODO] implement methods

        # K Nearest Neighbor
        def euclidean_distance(x1, x2):
            return np.sqrt(np.sum((x1 - x2) ** 2))
        
        def knn_classifier(train_data, train_labels, test_data, test_labels, k):
            predictions = [] # Initialize predictions list

            for test_point in test_data: # Loop through each test sample

                # Calculate distances between test point and all train points
                distances = [euclidean_distance(test_point, train_point) for train_point in train_data]
                nearest_indices = np.argsort(distances)[:k] # Get indices of k nearest neighbors
                nearest_labels = [train_labels[i] for i in nearest_indices] # Get labels of k nearest neighbors

                # Predict the class based on majority vote
                predicted_label = max(set(nearest_labels), key=nearest_labels.count)
                predictions.append(predicted_label) # Append the predicted label to the predictions list

            # Calculate ROC-AUC for all digits
            roc_auc = roc_auc_score(test_labels, predictions, average='macro')

            return roc_auc
        
        # Calculate ROC-AUC for k=1、5、10
        roc_auc_k1 = knn_classifier(train_data, train_label, test_data, test_label, k=1)
        roc_auc_k5 = knn_classifier(train_data, train_label, test_data, test_label, k=5)
        roc_auc_k10 = knn_classifier(train_data, train_label, test_data, test_label, k=10)

        # [TODO] record ROC-AUC for each method
        
        # Append ROC-AUC scores to respective lists
        roc_auc_scores_k1.append(roc_auc_k1)
        roc_auc_scores_k5.append(roc_auc_k5)
        roc_auc_scores_k10.append(roc_auc_k10)

        # Print the results
        print("ROC-AUC for k=1:", roc_auc_k1)
        print("ROC-AUC for k=5:", roc_auc_k5)
        print("ROC-AUC for k=10:", roc_auc_k10)

    # [TODO] print the average ROC-AUC for each method
    
    # Calculate average ROC-AUC scores for each method
        mean_roc_auc_k1 = np.mean(roc_auc_scores_k1)
        mean_roc_auc_k5 = np.mean(roc_auc_scores_k5)
        mean_roc_auc_k10 = np.mean(roc_auc_scores_k10)

        # Print the average ROC-AUC scores
        print("Average ROC-AUC for k=1:", mean_roc_auc_k1)
        print("Average ROC-AUC for k=5:", mean_roc_auc_k5)
        print("Average ROC-AUC for k=10:", mean_roc_auc_k10)
        
        #cluster-based
        def k_means_clustering(train_data, k, max_iter=100):
            centroids = train_data[np.random.choice(train_data.shape[0], k, replace=False)] # Initialize centroids randomly
            for _ in range(max_iter): # Assign each data point to the nearest centroid
                clusters = [[] for _ in range(k)]
                for i, data_point in enumerate(train_data):
                    distances = [euclidean_distance(data_point, centroid) for centroid in centroids]
                    cluster_index = np.argmin(distances)
                    clusters[cluster_index].append(i)
                
                # Update centroids
                new_centroids = []
                for cluster in clusters:
                    cluster_mean = np.mean(train_data[cluster], axis=0)
                    new_centroids.append(cluster_mean)
                new_centroids = np.array(new_centroids)
                
                # Check for convergence
                if np.allclose(centroids, new_centroids):
                    break
                centroids = new_centroids
                
            return clusters
        def calculate_roc_auc(train_labels, clusters, k):
            predictions = np.zeros_like(train_labels)
            for i, cluster in enumerate(clusters):
                predictions[cluster] = i
            
            # Compute ROC-AUC score
            roc_auc = roc_auc_score(train_labels, predictions, average='macro')
            return roc_auc

        # Set the number of clusters (k) to be used
        k_values = [1, 5, 10]
        roc_auc_scores = []

        for k in k_values:
            # Perform k-means clustering
            clusters = k_means_clustering(train_data, k)
            
            # Calculate ROC-AUC score
            roc_auc = calculate_roc_auc(train_label, clusters, k)
            roc_auc_scores.append(roc_auc)
        
        # Print the ROC-AUC scores for different values of k
        for k, roc_auc in zip(k_values, roc_auc_scores):
            print(f"  Mean ROC-AUC for k={k}: {roc_auc}")

        # distence-based
        def cosine_distance(u, v): # Compute cosine similarity
            dot_product = np.dot(u, v)
            norm_u = np.linalg.norm(u)
            norm_v = np.linalg.norm(v)
            cosine_similarity = dot_product / (norm_u * norm_v)
            # Convert cosine similarity to cosine distance
            cosine_distance = 1 - cosine_similarity
            return cosine_distance
        
        def minkowski_distance(u, v, r): # Compute Minkowski Distance
            minkowski_distance = np.power(np.sum(np.abs(u - v) ** r), 1/r)
            return minkowski_distance

        def mahalanobis_distance(u, v, cov):# Compute Mahalanobis Distance
            diff = u - v
            mahalanobis_distance = np.sqrt(np.dot(np.dot(diff.T, np.linalg.inv(cov)), diff))
            return mahalanobis_distance
    
        cov_matrix = np.cov(test_data, rowvar=False)
        
        from sklearn.metrics import roc_auc_score, pairwise_distances
        def k_nearest_neighbors(distances_matrix, train_labels, k):
            predictions = []
            for distances_to_train_samples in distances_matrix:
                nearest_neighbors_indices = np.argsort(distances_to_train_samples)[:k]
                nearest_neighbors_labels = [train_labels[i] for i in nearest_neighbors_indices]
                predicted_label = max(set(nearest_neighbors_labels), key=nearest_neighbors_labels.count)
                predictions.append(predicted_label)
            return predictions

        # ROC-AUC
        mean_roc_auc = {}
        for distance_name, distance_matrix in [("Cosine Distance", pairwise_distances(test_data, test_data, metric=cosine_distance)),
                                        ("Minkowski Distance r=1", pairwise_distances(test_data, test_data, metric=minkowski_distance, r=1)),
                                        ("Minkowski Distance r=2", pairwise_distances(test_data, test_data, metric=minkowski_distance, r=2)),
                                        ("Minkowski Distance r=inf", pairwise_distances(test_data, test_data, metric=minkowski_distance, r=np.inf)),
                                        ("Mahalanobis Distance", pairwise_distances(test_data, test_data, metric=mahalanobis_distance, cov=cov_matrix))]:
            predictions = k_nearest_neighbors(distance_matrix, train_label, k=5)
            # 計算每個數字的 ROC-AUC
            roc_auc_per_digit = {}
            for digit in range(2):
                true_labels = (test_label == digit).astype(int)
                predicted_scores = [(pred == digit) for pred in predictions]
                roc_auc_per_digit[digit] = roc_auc_score(true_labels, predicted_scores)
            mean_roc_auc[distance_name] = np.mean(list(roc_auc_per_digit.values()))

        print("  Mean ROC-AUC:")
        for distance_name, roc_auc in mean_roc_auc.items():
            print(f"{distance_name}: {roc_auc}")
        
        import matplotlib.pyplot as plt
        from scipy.spatial.distance import cdist    

        # Density-based
        # Prepare training data: label i as 0 and others as 1
        train_data_binary = orig_train_data.copy()
        train_label_binary = np.where(orig_train_label == i, 0, 1)

        # Prepare testing data: label i as 0 and others as 1
        test_data_binary, test_label_binary = resample(orig_test_data, orig_test_label, target_label=i, outlier_ratio=0.1)
        test_label_binary = np.where(test_label_binary == i, 0, 1)

        N=test_data.shape[0]
        k=5
        distance_matrix = cdist(test_data, train_data ,"euclidean")
        k_distance=np.sort(distance_matrix,axis=0)[k+1]
        k_distance_matrix=np.outer(np.ones(N),k_distance)
        reach_distacne=np.maximum(distance_matrix,k_distance_matrix)

        sort_index=np.argsort(distance_matrix,axis=1)[:,1:k+1]
        LRD=np.zeros(N)
        for i in range(N):
            LRD[i]=1/np.mean(reach_distacne[i,sort_index[i]]) 
        
        LOF=np.zeros(N)
        for i in range(N):
            LOF[i]=np.mean(LRD[sort_index[i]])/LRD[i]

        # Compute ROC-AUC for each class
        roc_auc_scores = []
        for i in range(10):
            binary_labels = np.where(test_label == i, 1, 0)
            roc_auc = roc_auc_score(binary_labels, LOF)
            roc_auc_scores.append(roc_auc)
            
        #(a)
        # Compute mean ROC-AUC
        mean_roc_auc = np.mean(roc_auc_scores)
        print("  Mean ROC-AUC:", mean_roc_auc)

        from sklearn.manifold import TSNE
        # 使用 t-SNE 將測試集數據轉換為低維表示
        tsne = TSNE(n_components=2)
        X_tsne = tsne.fit_transform(test_data)

        # 創建一個 Matplotlib 子圖
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

        # LOF 異常得分
        scatter1 = ax1.scatter(X_tsne[:, 0], X_tsne[:, 1], c=LOF, cmap='coolwarm', s=80)
        ax1.set_title('predicted LoF score for normal digit=0')

        # ground truth label
    scatter2 = ax2.scatter(X_tsne[:, 0], X_tsne[:, 1], c=test_label_binary, cmap='coolwarm', s=80, vmin = 0, vmax = 1)

    ax2.set_title('ground truth label for normal digit=0')

    # 
    cbar1 = fig.colorbar(scatter1, ax=ax1)
    cbar1.set_label('LOF Score')
    # cbar2 = fig.colorbar(scatter2, ax=ax2)
    # cbar2.set_label('Ground Truth Label')

    plt.show()